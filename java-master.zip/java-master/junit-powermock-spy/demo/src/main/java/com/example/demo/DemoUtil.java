package com.example.demo;

public class DemoUtil {

    public static String getRealString1(){
        return "realString1";
    }

    public static String getRealString2(){
        return "realString2";
    }

    public static void testVoid(){
        System.out.println("testVoid");
    }
}
